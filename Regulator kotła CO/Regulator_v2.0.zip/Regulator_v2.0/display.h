void initDisplay();
void putc(char c);
void clearDisplay();
void printDecimal(int Number);
void printHex(unsigned int Number);
void printString(char *String);
void gotoSecondLine();
void printByte(unsigned int theByte);
