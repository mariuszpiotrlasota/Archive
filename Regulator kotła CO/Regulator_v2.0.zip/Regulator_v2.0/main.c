

#include  <msp430x13x.h>
#include "lcd_4b.h"
#include "system.h"
#include "delay.h"
#include "program.h"
#include "1wire.h"
#include "PCF8593.h"



//4,0
#define S1IN  (P2IN&BIT6)
#define S2IN  (P2IN&BIT7)









void main(void)
{
  unsigned char _flaga=0;
    unsigned char data, data2;
    
    
  procesorWTDStop();
  procesorSetInternalCLK();
  
  //inicjalizacja 
  lcd_init();                         
  init_i2c();
  ResetPCF8593();

  




  
  set_main_text();
  

   
   
     while(1)
     {
       switch(_flaga){
         //-*****
           case 0:   
             ReadFlashMSP430();
             _flaga=1;
              break;
         
         
         //*********************************stan: PRACA
         case 1:    
              StanPRACA();
              ShowTimeOnLCD();

              //menu
              if(S1IN==0){wait_long2(); _flaga=11;} if(S2IN==0){wait_long2(); _flaga=12;} //ZMIEN STAN : ROZPALANIE/PRACA/WYGASZANIE
              
              if((S1IN==0)&&(S2IN==0)){wait_long2(); _flaga=2;}                  //WEJDZ W PROGRAMOWANIE
              break;

              
              
              
              
           
              
              
        //*********************************stan: PROGR. -ustaw temp. regulacji 
        case 2:     
              setTemRegKotlaOnLCD();
              if((S1IN==0)&&(S2IN==0)){wait_long2(); _flaga=3;}
              break;
          
              
              
              
         //*********************************stan: PROGR. -ustaw temp. wody
         case 3:   
              setTemRegWodyOnLCD();
              if((S1IN==0)&&(S2IN==0)){wait_long2(); 
                lcd_putstr_goto("C", 2,20);
                lcd_putstr_goto("C", 1,20);
                _flaga=4;}
              break;
              
              
        //*********************************stan: PROGR. -PRZEDMUCH
         case 4:   
              SetPrzedmuch();
              if((S1IN==0)&&(S2IN==0)){wait_long2();_flaga=5;}
              WriteFlashMSP430Data();
              break;
         
              
              
              
       //*********************************stan: PROGR. -ustaw czas       
       case 5:    
         
              SetTimeGodzOnLCD();
              if((S1IN==0)&&(S2IN==0)){wait_long2(); _flaga=6;}
              break;  
              
       case 6:    
              SetTimeMinOnLCD();
              if((S1IN==0)&&(S2IN==0)){wait_long2(); _flaga=7;}
              break;   
              
       case 7:         
              StoreDataOnPCF8593();
              _flaga=1;
              break; 
              
              
              
              
              
              
              
              
              
              
        //*********************************stan: ROZPAL      
        case 11:    
              StanROZPAL();    
              if(S1IN==0){wait_long2(); _flaga=6;}
              if(S2IN==0){wait_long2(); _flaga=0;}    
              wait_long2();wait_long2();wait_long2();
              _flaga=1;
              break;
              
              
              
              
        //*********************************stan: WYGASZ       
        case 12:    
              StanWYGASZ();
              if(S1IN==0){wait_long2(); _flaga=5;}
              if(S2IN==0){wait_long2(); _flaga=0;}
              wait_long2();wait_long2();wait_long2();
              _flaga=1;
              break;              
              
              
              
              
         //*********************************stan: WYGASZ      
         case 13:    
       
      
                        break;              
              
              
              
       }
       
       
    
           
           
     }
}




