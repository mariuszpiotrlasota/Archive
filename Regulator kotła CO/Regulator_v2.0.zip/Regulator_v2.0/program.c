#include "program.h"

  unsigned char G_TkotlaRegul; //warto�ci domy�lne
  unsigned char G_TwodyRegul;  //warto�ci domy�lne
  unsigned char G_Przedmuch;  //warto�ci domy�lne
  
  
  unsigned char temp_regul_dzies,temp_regul_jedno;  
  
  unsigned char _set=0;  
  unsigned char G_TkotlaAktualna=0,G_TwodyAktualna=0;
/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void set_main_text(void)
{
  lcd_putstr_goto("Tkotla",1,1); 
  lcd_putstr_goto("Twody", 2,1);
  lcd_putstr_goto("Totocz",3,1);
  lcd_putstr_goto(">",3,17);
  lcd_putstr_goto("00:00:00", 4,1);
  lcd_putstr_goto("DP", 4,11);
  
  lcd_putstr_goto("--C",1,18);  
  lcd_putstr_goto("--C",2,18);
}//set_main_text




  unsigned char temp_msb,temp_lsb;
  unsigned char  digit_1, digit_2, digit_3; 
  float temp;
  unsigned short int temp_c;
  unsigned char Tkotla=0,Twody=0;


  unsigned char Tcalkowita;
  unsigned short int rozdziel=625,Tulamek;
/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void setTempChanOnLCD(unsigned char channel) 
{
           WireReset(channel);wait_160us();
           WireWriteByte(0xcc,channel);wait_100us();
           WireWriteByte(0x44,channel);wait_100us(); 
           WireReset(channel);wait_160us(); 
           WireWriteByte(0xcc,channel);wait_100us();
           WireWriteByte(0xbe,channel);wait_100us();
           wait_160us();
           
        
           temp_lsb=WireReadByte(channel);//lsb
           temp_msb=WireReadByte(channel);//msb

           
           //*******************************************temp. ujenme
           if((temp_msb & 0x80)!=0){
                temp_c=(temp_msb<<8)+(temp_lsb);
                Tcalkowita=(temp_c>>4);
                Tcalkowita=0xff-Tcalkowita;
                
                Tulamek=temp_c & 0x0f;//lsb -25
                Tulamek=(0x0f-Tulamek+1)*rozdziel;
                Tulamek=Tulamek/1000;
                
                 digit_1= Tcalkowita/10;
                 digit_2= (Tcalkowita)-(digit_1*10);
                 digit_3= Tulamek;
           }
           
           
           
             //*******************************************temp. dodatnie
         else{
                 temp_c=(temp_msb<<8)+temp_lsb;
                 Tcalkowita=(temp_c>>4);
                 Tulamek=(temp_c & 0x0F)*rozdziel;
                 Tulamek=Tulamek/1000;
                 
                 
                 digit_1= Tcalkowita/10;
                 digit_2= (Tcalkowita)-(digit_1*10);
                 digit_3= Tulamek;
           }
           
           
           
           
           //obliczenia temp. do procesu regulacji
               switch(channel){
                  case 1: lcd_poz(1,10); G_TkotlaAktualna=((digit_1*10) + digit_2); break;
                  case 2: lcd_poz(2,10); G_TwodyAktualna=((digit_1*10) + digit_2); break;
                  case 3: lcd_poz(3,10);  break;
               }
               
           
           
           //wy�wietl na LCD temperatury
               if(temp_msb & 0x80){lcd_putc('-');}
               else{lcd_putc('+');}
           
               lcd_znak(digit_1);
               lcd_znak(digit_2);
               lcd_putc('.');
               lcd_znak(digit_3);
               
              switch(channel){
                  case 1: lcd_putstr("C /");     break;
                  case 2: lcd_putstr("C /");    break;
                  case 3: lcd_putstr("C");     break;
               }
               
               
                  
}

/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void SetKotlaWentylatorOFF(void){
     lcd_putstr_goto("-", 4,11);         
}

/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void SetKotlaWentylatorON(void){
     lcd_putstr_goto("W", 4,11);         
}
       
/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void SetPompaOFF(void){
     lcd_putstr_goto("-", 4,12);         
}

/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void SetPompaON(void){
     lcd_putstr_goto("P", 4,12);         
}
       


/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void RegulacjaWody(void){
         
        temp_regul_dzies=G_TwodyRegul/10;     //dziesietna
        temp_regul_jedno=G_TwodyRegul-temp_regul_dzies*10;    //jednost
          
          lcd_putstr_goto("", 2,18); lcd_znak(temp_regul_dzies);
          lcd_putstr_goto("", 2,19); lcd_znak(temp_regul_jedno);       
  
 if(G_TwodyAktualna<G_TwodyRegul)
    {SetPompaON();}
 else 
    {SetPompaOFF();}      
}
       

/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void RegulacjaKotla(void){
 // G_TkotlaRegul
    
        temp_regul_dzies=G_TkotlaRegul/10;     //dziesietna
        temp_regul_jedno=G_TkotlaRegul-temp_regul_dzies*10;    //jednost
          
          lcd_putstr_goto("", 1,18); lcd_znak(temp_regul_dzies);
          lcd_putstr_goto("", 1,19); lcd_znak(temp_regul_jedno);
          
          
    
    
  
if(G_TkotlaAktualna<G_TkotlaRegul)
    {SetKotlaWentylatorON();}
 else 
    {SetKotlaWentylatorOFF();}
  
}
       


/**************************************************************************************************************************
procedura:
RegulacjaPrzedmuch 	: 
**************************************************************************************************************************/
void RegulacjaPrzedmuch(void){
 
   //wy�wietl aktualny przedmuch
   switch(G_Przedmuch){
            case 0: lcd_putstr_goto(">", 3,17); wait_long();break; 
            case 1: lcd_putstr_goto(">>", 3,17); wait_long();break; 
            case 2: lcd_putstr_goto(">>>", 3,17); wait_long();break; 
            case 3: lcd_putstr_goto(">>>>", 3,17); wait_long();break; 
          }
   
}


/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void StanPRACA(void){
              lcd_putstr_goto("s:PRACA", 4,14);
              setTempChanOnLCD(1);
              wait_short();
              setTempChanOnLCD(2);
              wait_short();
              setTempChanOnLCD(3);
              wait_short(); 
              RegulacjaKotla();
              RegulacjaWody();
              RegulacjaPrzedmuch();
}
              
  

/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void StanROZPAL(void){
              lcd_putstr_goto("s:ROZPA", 4,14);
              setTempChanOnLCD(1);
              wait_short();
              setTempChanOnLCD(2);
              wait_short();
              setTempChanOnLCD(3);
              wait_short();  
}
   


/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void StanWYGASZ(void){
              lcd_putstr_goto("s:WYGAS", 4,14);
              setTempChanOnLCD(1);
              wait_short();
              setTempChanOnLCD(2);
              wait_short();
              setTempChanOnLCD(3);
              wait_short();  
}
              




/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void setTemRegKotlaOnLCD(void){
        
          
          lcd_putstr_goto("s:PROG1", 4,14);
          lcd_putstr_goto("C", 1,20);
          lcd_putstr_goto("-- ", 2,18);          
          temp_regul_dzies=Tkotla/10;     //dziesietna
          temp_regul_jedno=Tkotla-temp_regul_dzies*10;    //jednost
         
  
            
               
          
          lcd_putstr_goto("", 1,18); lcd_znak(temp_regul_dzies);
          lcd_putstr_goto("", 1,19); lcd_znak(temp_regul_jedno);
          if(S1IN==0){wait_long();Tkotla++;  }
          if(S2IN==0){wait_long();Tkotla--;  }
          if(Tkotla>99){Tkotla=0;}if(Tkotla<0){Tkotla=99;}
          
          G_TkotlaRegul=((temp_regul_dzies*10) + (temp_regul_jedno));
          

}



/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void setTemRegWodyOnLCD(void){
          lcd_putstr_goto("s:PROG2", 4,14);
          lcd_putstr_goto("C", 2,20);
          lcd_putstr_goto(" ", 1,20);
          
          temp_regul_dzies=Twody/10;
          temp_regul_jedno=Twody-temp_regul_dzies*10;
          
          lcd_putstr_goto("", 2,18); lcd_znak(temp_regul_dzies);
          lcd_putstr_goto("", 2,19); lcd_znak(temp_regul_jedno);
          if(S1IN==0){wait_long();Twody++;  }
          if(S2IN==0){wait_long();Twody--;  }
            if(Twody>99){Twody=0;}if(Twody<0){Twody=99;}
          
          G_TwodyRegul=((temp_regul_dzies*10) + (temp_regul_jedno));
}






/**************************************************************************************************************************
procedura:
	: 
**************************************************************************************************************************/
unsigned char get_min, get_sek, get_godz;
void ShowTimeOnLCD(void){

          //pobierz wartosci
          get_godz=czytaj_data_i2c(PCF8593_godz);
          get_min=czytaj_data_i2c(PCF8593_min); 
          get_sek=czytaj_data_i2c(PCF8593_sek);
          
          
          //sekundy           
          lcd_putstr_goto("", 4,7); lcd_znak((get_sek & 0xF0)>>4);
          lcd_putstr_goto("", 4,8); lcd_znak(get_sek & 0x0F);
          
          
          //minuty       
          lcd_putstr_goto(":",4,6);
          lcd_putstr_goto("", 4,4); lcd_znak((get_min & 0xF0)>>4);
          lcd_putstr_goto("", 4,5); lcd_znak(get_min & 0x0F);

          //godziny           
          lcd_putstr_goto(":",4,3);
          lcd_putstr_goto("", 4,1); lcd_znak((get_godz & 0xF0)>>4);
          lcd_putstr_goto("", 4,2); lcd_znak(get_godz & 0x0F);
          if( ((get_godz & 0xF0)>>4)>2){                              //warunek na 24h
            if( (get_godz & 0xF0)>4 ){ wpisz_data_i2c(0x04,0x00);}
           }
}





/**************************************************************************************************************************
procedura:
	: 
**************************************************************************************************************************/
unsigned char  set_godz_licz=0, set_godz_dzies, set_godz_jedn;
void SetTimeGodzOnLCD(void){
  
       
          if(S1IN==0){wait_long();set_godz_licz++; }
          if(S2IN==0){wait_long();set_godz_licz--;  }
          
          lcd_putstr_goto("s:PROG4", 4,14);
          lcd_putstr_goto(":--   ", 4,3);
          
         
          set_godz_dzies=set_godz_licz/10;             //dziesietne
          set_godz_jedn=set_godz_licz-set_godz_dzies*10;    //jednostkowe
          
          lcd_putstr_goto("", 4,1); lcd_znak(set_godz_dzies);
          lcd_putstr_goto("", 4,2); lcd_znak(set_godz_jedn);
    
            if(set_godz_licz>23){set_godz_licz=0;}
            if(set_godz_licz<0){set_godz_licz=23;}


}



/**************************************************************************************************************************
procedura:
	: 
**************************************************************************************************************************/
unsigned char set_min_licz=0, set_min_dzies, set_min_jedn;
void SetTimeMinOnLCD(void){
         
          if(S1IN==0){wait_long();set_min_licz++; }
          if(S2IN==0){wait_long();set_min_licz--;  }
          
          lcd_putstr_goto("s:PROG4", 4,14);
          lcd_putstr_goto("   ", 4,6);
          
         
          set_min_dzies = set_min_licz/10;             //dziesietne
          set_min_jedn = set_min_licz - set_min_dzies*10;    //jednostkowe
          
          lcd_putstr_goto("", 4,4); lcd_znak(set_min_dzies);
          lcd_putstr_goto("", 4,5); lcd_znak(set_min_jedn);
    
            if(set_min_licz>59){set_min_licz=0;}
            if(set_min_licz<0){set_min_licz=59;}


}



/**************************************************************************************************************************
procedura:
	: 
**************************************************************************************************************************/
void StoreDataOnPCF8593(void){
  wpisz_data_i2c(PCF8593_godz,( (set_godz_dzies<<4) + (set_godz_jedn) ));
  wpisz_data_i2c(PCF8593_min,( (set_min_dzies<<4) + (set_min_jedn) ));
  wpisz_data_i2c(PCF8593_sek,0x00); //zeruj sekundy
  
  wpisz_data_i2c(PCF8593_reg_kotla,G_TkotlaRegul); //wpisz reg. 
  wpisz_data_i2c(PCF8593_reg_wody,G_TwodyRegul);  //wpisz reg. 
}


void  SetPrzedmuch(void){
          if(S1IN==0){wait_long();G_Przedmuch++; }
          if(S2IN==0){wait_long();G_Przedmuch--; }  
    
          lcd_putstr_goto("s:PROG3", 4,14);
          lcd_putstr_goto("    ", 3,17); 
          
          switch(G_Przedmuch){
            case 0: lcd_putstr_goto(">", 3,17); wait_long();break; 
            case 1: lcd_putstr_goto(">>", 3,17); wait_long();break; 
            case 2: lcd_putstr_goto(">>>", 3,17); wait_long();break; 
            case 3: lcd_putstr_goto(">>>>", 3,17); wait_long();break; 
          }
          if(G_Przedmuch>3){G_Przedmuch=0;}
          if(G_Przedmuch<0){G_Przedmuch=3;}
}






/**************************************************************************************************************************
procedura:
WriteFlashMSP430		: 
**************************************************************************************************************************/
void WriteFlashMSP430 (unsigned char Tkotla, unsigned char Twody, unsigned char Przedmuch )
{
  char *Flash_ptr;                          // Flash pointer


  Flash_ptr = (char *) 0x1080;              // Initialize Flash pointer
  FCTL1 = FWKEY + ERASE;                    // Set Erase bit
  FCTL3 = FWKEY;                            // Clear Lock bit
  *Flash_ptr = 0;                           // Dummy write to erase Flash segment

  FCTL1 = FWKEY + WRT;                      // Set WRT bit for write operation

    *Flash_ptr = Tkotla;                   // 0x1080
    *Flash_ptr++;
    *Flash_ptr = Twody;                    //0x1081
    *Flash_ptr++;
    *Flash_ptr = Przedmuch;                    //0x1082
    

  FCTL1 = FWKEY;                            // Clear WRT bit
  FCTL3 = FWKEY + LOCK;                     // Set LOCK bit
}//WriteFlashMSP430







/**************************************************************************************************************************
procedura:
ReadFlashMSP430Kotla		: 
**************************************************************************************************************************/

unsigned char ReadFlashMSP430_sector(unsigned char sector)
{
  char *Flash_ptrA;                         // Segment A wskaznik
  unsigned char flash_data; 
  
  Flash_ptrA = (char *) 0x1080;             // Initialize Flash segment A pointer

  for(unsigned int i=0;i<sector;i++){ 
    flash_data = *Flash_ptrA;           // copy value segment A to segment B
  *Flash_ptrA++;  
  }
  
  return(flash_data);
}//ReadFlashMSP430Kotla




/**************************************************************************************************************************
procedura:
ReadFlashMSP430Kotla		: 
**************************************************************************************************************************/
void WriteFlashMSP430Data(void)
{
  WriteFlashMSP430(G_TkotlaRegul,G_TwodyRegul,G_Przedmuch);
}



/**************************************************************************************************************************
procedura:
	: 
**************************************************************************************************************************/
void ReadFlashMSP430(void){

       G_TkotlaRegul=ReadFlashMSP430_sector(1);
       G_TwodyRegul=ReadFlashMSP430_sector(2);
       G_Przedmuch=ReadFlashMSP430_sector(3);

}
