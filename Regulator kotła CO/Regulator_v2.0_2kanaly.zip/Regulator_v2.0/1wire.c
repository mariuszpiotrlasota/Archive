#include  "1wire.h"




/**************************************************************************************************************************
procedura:
obsluga 1wire		: zwraca adres docelowy ramki
*************************************************************************************************************************/
void OutWire(void){dir_1wire|=bit_1wire;}//OutWire
void InWire(void){dir_1wire &= ~bit_1wire;}//InWire
void SetWire(void){port_1wire|=bit_1wire; }//SetWire
void ClrWire(void){port_1wire&=~bit_1wire; }//ClrWire

void OutWire2(void){dir_1wire|=bit_1wire;}//OutWire
void InWire2(void){dir_1wire &= ~bit_1wire;}//InWire
void SetWire2(void){port_1wire|=bit_1wire; }//SetWire
void ClrWire2(void){port_1wire&=~bit_1wire; }//ClrWire


void OutWireChan(unsigned char channel){
  switch(channel){
  case 1: dir_1wire|=bit_1wire; break;
  case 2: dir_2wire|=bit_2wire; break;
  }
  
    
}//OutWire

void InWireChan(unsigned char channel){
  switch(channel){
  case 1: dir_1wire &= ~bit_1wire; break;
  case 2: dir_2wire &= ~bit_2wire; break;
  }
    
}//InWire

void SetWireChan(unsigned char channel){
  switch(channel){
  case 1:  port_1wire|=bit_1wire; break;
  case 2:  port_2wire|=bit_2wire; break;
  }    
}//SetWire

void ClrWireChan(unsigned char channel){
  switch(channel){
  case 1: port_1wire&=~bit_1wire; break;
  case 2: port_2wire&=~bit_2wire; break;
  }
}//ClrWire



/**************************************************************************************************************************
procedura:
WireInit		: zwraca adres docelowy ramki
**************************************************************************************************************************/
void WireInit(unsigned char channel){
  OutWireChan(channel);
  SetWireChan(channel);
}//WireInit






/**************************************************************************************************************************
procedura:
WireReset		: zwraca adres docelowy ramki
**************************************************************************************************************************/
unsigned char WireReset(unsigned char channel){
 unsigned char enable_wire=0; 
  OutWireChan(channel);    //Pull line low and wait for 480uS
  ClrWireChan(channel);
  wait_500us();
   
  InWireChan(channel);
                          //Release line and wait for 60uS
  switch(channel){
  case 1: if(pin_1wire & bit_1wire) {enable_wire=1;} break;
  case 2: if(pin_2wire & bit_2wire) {enable_wire=1;} break;
  }

  return enable_wire;

}//WireReset




/**************************************************************************************************************************
procedura:
Read		: zwraca adres docelowy ramki
**************************************************************************************************************************/
/**************************************************************************************************************************
procedura:
Read		: zwraca adres docelowy ramki
**************************************************************************************************************************/
unsigned char WireReadBit(void){
  unsigned char rx_bit=0;
  OutWire();
  
  ClrWire(); 
  wait_10us(); 
  SetWire();
  wait_10us();
    
  InWire();
  if((pin_1wire & bit_1wire)==1) {rx_bit=1;} //Read line value
  else{rx_bit=0;}
  
  return(rx_bit); // return value of DQ line
}


unsigned char WireReadByte(void){
  unsigned char i=8;
  unsigned char rx_buffor = 0;
  
  for(i=0;i<8;i++)
  {
    if(WireReadBit()) rx_buffor|=0x01<<i;
     wait_40us(); 
  }
  
  /*
  while(i--)
  {
      
      rx_buffor>>=1;
      rx_buffor|=(WireReadBit()<<7);
  }*/
  return(rx_buffor);

}//WireRead



/**************************************************************************************************************************
procedura:
Read		: zwraca adres docelowy ramki
**************************************************************************************************************************/
unsigned char WireReadBit2(void){
  unsigned char rx_bit=0;
  OutWire2();
  
  ClrWire2(); 
  wait_10us(); 
  SetWire2();
  wait_10us();
    
  InWire2();
  if((pin_2wire & bit_2wire)==1) {rx_bit=1;} //Read line value
  else{rx_bit=0;}
  
  return(rx_bit); // return value of DQ line
}


unsigned char WireReadByte2(void){
  unsigned char i=8;
  unsigned char rx_buffor = 0;
  
  for(i=0;i<8;i++)
  {
    if(WireReadBit2()) rx_buffor|=0x01<<i;
     wait_40us(); 
  }
    return(rx_buffor);

}//WireRead






/**************************************************************************************************************************
procedura:
WireWriteBit		: 
**************************************************************************************************************************/
void WireWriteBit(char tx_bit, unsigned char channel){
  ClrWireChan(channel); 
  if(tx_bit==1){SetWireChan(channel);}  //1
  else {ClrWireChan(channel);}       //0
   wait_40us();
   SetWireChan(channel); 
}


void WireWriteByte(char tx_byte, unsigned char channel){
   unsigned char i;
   unsigned char pom;
      OutWireChan(channel); 

  for(i=0;i<8;i++)
  {
    pom=tx_byte>>i;
    pom &= 0x01;
    WireWriteBit(pom,channel);
  }
  SetWireChan(channel);

}//WireWrite

