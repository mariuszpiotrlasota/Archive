

#include  <msp430x13x.h>
#include "lcd_4b.h"
#include "system.h"
#include "delay.h"
#include "program.h"
#include "1wire.h"

//4,0

void main(void)
{
  procesorWTDStop();

  procesorSetInternalCLK();

  
  
  lcd_init();                          //inicjalizacja LCD 
  set_main_text();

 
 




     while(1)
     {
      set_temp2();
 wait_short();

           
           
           
           
      
     }
}

