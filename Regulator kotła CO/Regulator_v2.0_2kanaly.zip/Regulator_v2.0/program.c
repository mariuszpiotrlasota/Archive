#include "program.h"

/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void set_main_text(void)
{
  lcd_putstr_goto("Tkotla",1,1); 
  lcd_putstr_goto("Twody", 2,1);
  lcd_putstr_goto("Totocz",3,1);
  lcd_putstr_goto("12:45", 4,1);
}//set_main_text


  unsigned char temp_msb,temp_lsb;
  unsigned char digit_1, digit_2, digit_3; 
  float temp;
  unsigned short int temp_c;

/**************************************************************************************************************************
procedura:
set_main_text 	: 
**************************************************************************************************************************/
void set_temp(unsigned char channel) 
{
           WireReset(channel);wait_160us();
           WireWriteByte(0xcc,channel);wait_100us();
           WireWriteByte(0x44,channel);wait_100us(); 
           WireReset();wait_160us(); 
           WireWriteByte(0xcc,channel);wait_100us();
           WireWriteByte(0xbe,channel);wait_100us();
           wait_160us();wait_160us();
           
           temp_lsb=WireReadByte(channel);//lsb
           temp_msb=WireReadByte(channel);//msb
           
           temp=(float)(temp_lsb+(temp_msb*256))/16;
           temp_c=temp*100;
                      
           digit_1= temp_c/1000;
           digit_2= (temp_c/100)-(digit_1*10);
           digit_3= (temp_c/10)- (digit_2*10+digit_1*100);
           
           switch(channel){
           case 1: 
             lcd_poz(1,10); 
             if(temp_msb & 0x80){lcd_znak('-');}
             else{lcd_znak('+');}
             lcd_znak(digit_1);
             lcd_znak(digit_2);
             lcd_putc('.');
             lcd_znak(digit_3);
             lcd_putstr("C / ");
             break;
             
           case 2: 
             lcd_poz(2,10); 
             if(temp_msb & 0x80){lcd_znak('-');}
             else{lcd_znak('+');}
             lcd_znak(digit_1);
             lcd_znak(digit_2);
             lcd_putc('.');
             lcd_znak(digit_3);
             lcd_putstr("C / ");
             break;
             
             
           }
                      
           wait_short();  
      
}


void set_temp2(void) 
{
           WireReset(2);wait_160us();
           WireWriteByte(0xcc,2);wait_100us();
           WireWriteByte(0x44,2);wait_100us(); 
           WireReset();wait_160us(); 
           WireWriteByte(0xcc,2);wait_100us();
           WireWriteByte(0xbe,2);wait_100us();
           wait_160us();wait_160us();
           
           temp_lsb=WireReadByte2();//lsb
           temp_msb=WireReadByte2();//msb
           
           temp=(float)(temp_lsb+(temp_msb*256))/16;
           temp_c=temp*100;
                      
           digit_1= temp_c/1000;
           digit_2= (temp_c/100)-(digit_1*10);
           digit_3= (temp_c/10)- (digit_2*10+digit_1*100);
           
           switch(1){
           case 1: 
             lcd_poz(3,10); 
             if(temp_msb & 0x80){lcd_znak('-');}
             else{lcd_znak('+');}
             lcd_znak(digit_1);
             lcd_znak(digit_2);
             lcd_putc('.');
             lcd_znak(digit_3);
             lcd_putstr("C / ");
             break;
             
           case 2: 
             lcd_poz(2,10); 
             if(temp_msb & 0x80){lcd_znak('-');}
             else{lcd_znak('+');}
             lcd_znak(digit_1);
             lcd_znak(digit_2);
             lcd_putc('.');
             lcd_znak(digit_3);
             lcd_putstr("C / ");
             break;
             
             
           }
                      
           wait_short();  
      
}
