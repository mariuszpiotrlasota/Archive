#include  "disp_seven.h"
#include  <msp430x12x2.h>

volatile char select_com[2]={~(com1),~(com2)};


