

void init(void);




void set1_E1(void);
void set1_E2(void);
void set1_E3(void);
void set1_E4(void);
void set1_E5(void);
void set1_E6(void);
void set1_E7(void);
void set2_E1(void);
void set2_E2(void);
void set2_E3(void);
void set2_E4(void);
void set2_E5(void);
void set2_E6(void);
void set2_E7(void);