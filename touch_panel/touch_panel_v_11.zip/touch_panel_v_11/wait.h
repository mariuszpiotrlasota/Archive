
void wait_short(void);
void wait_long(void);
void wait(unsigned int x);
